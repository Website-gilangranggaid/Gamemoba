# GilangMOBA Lite — paket Android

Game HTML5 (satu file: `www/index.html`) yang dibungkus dengan Capacitor menjadi APK.

## Cara 1 — Build sendiri (butuh Android SDK)
Prasyarat: Node 18+, JDK 17, Android SDK (variabel `ANDROID_HOME`).

    ./build-apk.sh

Hasil: `android/app/build/outputs/apk/debug/app-debug.apk` (bisa langsung di-install ke HP,
aktifkan "Install dari sumber tidak dikenal").

## Cara 2 — Tanpa Android Studio (paling mudah)
1. Taruh `www/index.html` di hosting HTTPS (GitHub Pages / Netlify / Vercel).
2. Buka https://www.pwabuilder.com, masukkan URL-nya, pilih **Android** dan unduh APK/AAB.

## Cara 3 — Android Studio
Jalankan `npm install @capacitor/core @capacitor/cli @capacitor/android && npx cap add android && npx cap sync android`,
lalu `npx cap open android` dan tekan Run / Build APK.

## Catatan
- Font Cinzel & Rajdhani dimuat dari Google Fonts (perlu internet). Tanpa internet, game memakai font cadangan sistem.
  Untuk offline penuh, unduh file font dan sematkan lewat `@font-face`.
- Semua musik & efek suara dibuat langsung oleh kode (WebAudio), tidak ada file audio eksternal.
- Progres (koin, kristal, skin) tersimpan di localStorage perangkat.
- Ikon aplikasi: ganti file di `android/app/src/main/res/mipmap-*` (atau pakai `@capacitor/assets`).
